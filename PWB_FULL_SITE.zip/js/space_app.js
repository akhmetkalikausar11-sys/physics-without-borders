const sCanvas = document.getElementById('space-canvas');
const sCtx = sCanvas.getContext('2d');

let rotX = 0.48, rotY = 0.0, zoom = 1.0, speedMult = 1.0, simT = 0;
let sceneMode = 'solar';
let selected = SPACE_OBJECTS.find(o => o.id === 'earth');
let nodes = [];
let drag = false, lx = 0, ly = 0;

const starsBg = Array.from({ length: 180 }, () => ({
    x: (Math.random() - 0.5) * 1400,
    y: (Math.random() - 0.5) * 1400,
    z: (Math.random() - 0.5) * 1400,
    r: Math.random() * 1.5 + 0.5
}));

function resizeSpace() {
    sCanvas.width = sCanvas.clientWidth;
    sCanvas.height = sCanvas.clientHeight;
}
window.addEventListener('resize', resizeSpace);
resizeSpace();

function project(x, y, z) {
    const cy = Math.cos(rotY), sy = Math.sin(rotY);
    const x1 = x * cy - z * sy;
    const z1 = z * cy + x * sy;
    const cx = Math.cos(rotX), sx = Math.sin(rotX);
    const y2 = y * cx - z1 * sx;
    const z2 = z1 * cx + y * sx;
    const scale = (650 / (650 + z2 + 340)) * zoom;
    return { x: sCanvas.width / 2 + x1 * scale, y: sCanvas.height / 2 + y2 * scale, s: scale, z: z2 };
}

function showInspector(obj) {
    selected = obj;
    const G = 6.6743e-11;
    const v1 = Math.sqrt((G * obj.massKg) / (obj.rKm * 1000)) / 1000;
    document.getElementById('space-inspector').innerHTML = `
        <div class="panel-title">
            <span>${obj.name}</span>
            <span class="badge" style="margin:0;">${obj.type}</span>
        </div>
        <div style="display:flex; align-items:center; gap:16px; margin-bottom:14px;">
            <div style="width:54px; height:54px; border-radius:50%; flex-shrink:0;
                background: radial-gradient(circle at 30% 30%, ${obj.color}, ${obj.color2});
                box-shadow: 0 0 20px ${obj.color}66;"></div>
            <p style="color:var(--text-muted); font-size:0.9rem;">${obj.desc}</p>
        </div>
        <div class="metrics-grid">
            <div class="metric-box"><div class="metric-title">Радиус</div><div class="metric-value">${obj.rKm.toLocaleString('ru-RU')} км</div></div>
            <div class="metric-box"><div class="metric-title">Масса</div><div class="metric-value">${obj.massKg.toExponential(2)} кг</div></div>
            <div class="metric-box"><div class="metric-title">Гравитация (g)</div><div class="metric-value">${obj.g} м/с²</div></div>
            <div class="metric-box"><div class="metric-title">Температура</div><div class="metric-value">${obj.temp}</div></div>
            <div class="metric-box"><div class="metric-title">1-я косм. скорость</div><div class="metric-value">${v1.toFixed(2)} км/с</div></div>
            <div class="metric-box"><div class="metric-title">Спутники</div><div class="metric-value">${obj.moons}</div></div>
        </div>
    `;
}

function drawSpace() {
    sCtx.clearRect(0, 0, sCanvas.width, sCanvas.height);

    // Звёзды на фоне
    sCtx.fillStyle = 'rgba(255,255,255,0.6)';
    starsBg.forEach(st => {
        const p = project(st.x, st.y, st.z);
        if (p.s > 0) {
            sCtx.beginPath();
            sCtx.arc(p.x, p.y, st.r * Math.min(1.4, p.s), 0, Math.PI * 2);
            sCtx.fill();
        }
    });

    nodes = [];
    if (sceneMode === 'solar') {
        const solarIds = ['sun', 'mercury', 'venus', 'earth', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune', 'pluto', 'halley'];
        solarIds.forEach((id, idx) => {
            const obj = SPACE_OBJECTS.find(o => o.id === id);
            if (obj.orbitR > 0) {
                sCtx.strokeStyle = 'rgba(148, 163, 184, 0.22)';
                sCtx.lineWidth = 1;
                sCtx.beginPath();
                for (let a = 0; a <= Math.PI * 2 + 0.1; a += 0.12) {
                    const op = project(Math.cos(a) * obj.orbitR, 0, Math.sin(a) * obj.orbitR);
                    if (a === 0) sCtx.moveTo(op.x, op.y);
                    else sCtx.lineTo(op.x, op.y);
                }
                sCtx.stroke();
            }
            const ang = simT * obj.speed * 0.45 + idx * 1.1;
            const px = Math.cos(ang) * obj.orbitR;
            const pz = Math.sin(ang) * obj.orbitR;
            const p = project(px, 0, pz);
            if (p.s > 0) nodes.push({ obj, sx: p.x, sy: p.y, sr: obj.visR * p.s, z: p.z });

            if (id === 'earth') {
                const moon = SPACE_OBJECTS.find(o => o.id === 'moon');
                const mp = project(px + Math.cos(simT * 4) * 15, 0, pz + Math.sin(simT * 4) * 15);
                if (mp.s > 0) nodes.push({ obj: moon, sx: mp.x, sy: mp.y, sr: moon.visR * mp.s, z: mp.z });
            }
        });
    } else {
        const deep = SPACE_OBJECTS.filter(o => o.cat !== 'planets' || o.id === 'earth');
        deep.forEach((obj, idx) => {
            const r = 80 + (idx % 3) * 75;
            const ang = (idx / deep.length) * Math.PI * 2 + simT * 0.1;
            const py = ((idx % 3) - 1) * 38;
            const p = project(Math.cos(ang) * r, py, Math.sin(ang) * r);
            if (p.s > 0) nodes.push({ obj, sx: p.x, sy: p.y, sr: obj.visR * p.s, z: p.z });
        });
    }

    nodes.sort((a, b) => b.z - a.z);
    nodes.forEach(n => {
        const { obj, sx, sy, sr } = n;
        const r = Math.max(3.5, sr);

        if (obj.cat === 'stars' || obj.cat === 'blackholes') {
            const glow = sCtx.createRadialGradient(sx, sy, r * 0.2, sx, sy, r * 2.4);
            glow.addColorStop(0, obj.color);
            glow.addColorStop(1, 'rgba(0,0,0,0)');
            sCtx.fillStyle = glow;
            sCtx.beginPath();
            sCtx.arc(sx, sy, r * 2.4, 0, Math.PI * 2);
            sCtx.fill();
        }

        if (obj.rings) {
            sCtx.strokeStyle = 'rgba(254, 240, 138, 0.7)';
            sCtx.lineWidth = Math.max(2, r * 0.35);
            sCtx.beginPath();
            sCtx.ellipse(sx, sy, r * 2.1, r * 0.6, 0.25, 0, Math.PI * 2);
            sCtx.stroke();
        }

        const sphereGrad = sCtx.createRadialGradient(sx - r * 0.3, sy - r * 0.3, r * 0.1, sx, sy, r);
        sphereGrad.addColorStop(0, obj.color);
        sphereGrad.addColorStop(1, obj.color2);
        sCtx.fillStyle = obj.cat === 'blackholes' ? '#000' : sphereGrad;
        sCtx.beginPath();
        sCtx.arc(sx, sy, r, 0, Math.PI * 2);
        sCtx.fill();

        if (selected && selected.id === obj.id) {
            sCtx.strokeStyle = '#38bdf8';
            sCtx.lineWidth = 2;
            sCtx.beginPath();
            sCtx.arc(sx, sy, r + 5, 0, Math.PI * 2);
            sCtx.stroke();
        }

        sCtx.fillStyle = '#e2e8f0';
        sCtx.font = '12px Segoe UI, sans-serif';
        sCtx.fillText(obj.name, sx + r + 5, sy + 4);
    });

    simT += 0.016 * speedMult;
    requestAnimationFrame(drawSpace);
}

sCanvas.addEventListener('mousedown', e => { drag = true; lx = e.clientX; ly = e.clientY; });
window.addEventListener('mousemove', e => {
    if (!drag) return;
    rotY += (e.clientX - lx) * 0.006;
    rotX = Math.max(-1.4, Math.min(1.4, rotX + (e.clientY - ly) * 0.006));
    lx = e.clientX; ly = e.clientY;
});
window.addEventListener('mouseup', e => {
    if (drag && Math.hypot(e.clientX - lx, e.clientY - ly) < 5) {
        const rect = sCanvas.getBoundingClientRect();
        const mx = e.clientX - rect.left, my = e.clientY - rect.top;
        for (let i = nodes.length - 1; i >= 0; i--) {
            if (Math.hypot(mx - nodes[i].sx, my - nodes[i].sy) <= Math.max(14, nodes[i].sr + 5)) {
                showInspector(nodes[i].obj);
                break;
            }
        }
    }
    drag = false;
});
sCanvas.addEventListener('wheel', e => {
    e.preventDefault();
    zoom = Math.max(0.4, Math.min(3.0, zoom * (e.deltaY > 0 ? 0.92 : 1.08)));
    document.getElementById('sp-zoom').value = zoom;
    document.getElementById('sp-zoom-val').textContent = zoom.toFixed(1) + 'x';
}, { passive: false });

document.getElementById('sp-speed').addEventListener('input', e => {
    speedMult = parseFloat(e.target.value);
    document.getElementById('sp-speed-val').textContent = speedMult.toFixed(1) + 'x';
});
document.getElementById('sp-zoom').addEventListener('input', e => {
    zoom = parseFloat(e.target.value);
    document.getElementById('sp-zoom-val').textContent = zoom.toFixed(1) + 'x';
});
document.getElementById('mode-solar').addEventListener('click', e => {
    sceneMode = 'solar';
    e.target.classList.add('active');
    document.getElementById('mode-deep').classList.remove('active');
});
document.getElementById('mode-deep').addEventListener('click', e => {
    sceneMode = 'deep';
    e.target.classList.add('active');
    document.getElementById('mode-solar').classList.remove('active');
});

// Атлас
function renderAtlas(cat = 'all') {
    const list = cat === 'all' ? SPACE_OBJECTS : SPACE_OBJECTS.filter(o => o.cat === cat);
    document.getElementById('atlas-grid').innerHTML = list.map(o => `
        <div class="panel card-link" style="cursor:pointer;" onclick="focusObj('${o.id}')">
            <div>
                <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:10px;">
                    <span class="badge" style="margin:0;">${o.type}</span>
                    <div style="width:28px; height:28px; border-radius:50%; background:radial-gradient(circle at 30% 30%, ${o.color}, ${o.color2});"></div>
                </div>
                <h3 style="margin-bottom:6px;">${o.name}</h3>
                <p style="color:var(--text-muted); font-size:0.86rem; margin-bottom:10px;">${o.desc}</p>
            </div>
            <div style="font-size:0.84rem; color:#cbd5e1;">
                <div><strong>Масса:</strong> ${o.massKg.toExponential(2)} кг</div>
                <div><strong>Гравитация:</strong> ${o.g} м/с²</div>
            </div>
        </div>
    `).join('');
}

function focusObj(id) {
    const obj = SPACE_OBJECTS.find(o => o.id === id);
    if (!obj) return;
    showInspector(obj);
    sceneMode = (obj.cat === 'planets' || obj.id === 'sun' || obj.id === 'halley') ? 'solar' : 'deep';
    document.getElementById('mode-solar').classList.toggle('active', sceneMode === 'solar');
    document.getElementById('mode-deep').classList.toggle('active', sceneMode === 'deep');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.querySelectorAll('[data-cat]').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('[data-cat]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderAtlas(btn.dataset.cat);
    });
});

// Сравнение и калькулятор
const opts = SPACE_OBJECTS.map(o => `<option value="${o.id}">${o.name}</option>`).join('');
document.getElementById('cmp-a').innerHTML = opts;
document.getElementById('cmp-b').innerHTML = opts;
document.getElementById('cmp-a').value = 'earth';
document.getElementById('cmp-b').value = 'mars';

function updateCmp() {
    const a = SPACE_OBJECTS.find(o => o.id === document.getElementById('cmp-a').value);
    const b = SPACE_OBJECTS.find(o => o.id === document.getElementById('cmp-b').value);
    document.getElementById('cmp-table-wrap').innerHTML = `
        <table class="data-table">
            <thead><tr><th>Параметр</th><th>${a.name}</th><th>${b.name}</th></tr></thead>
            <tbody>
                <tr><td>Масса</td><td>${a.massKg.toExponential(2)} кг</td><td>${b.massKg.toExponential(2)} кг</td></tr>
                <tr><td>Радиус</td><td>${a.rKm.toLocaleString('ru-RU')} км</td><td>${b.rKm.toLocaleString('ru-RU')} км</td></tr>
                <tr><td>Гравитация</td><td>${a.g} м/с²</td><td>${b.g} м/с²</td></tr>
                <tr><td>Температура</td><td>${a.temp}</td><td>${b.temp}</td></tr>
            </tbody>
        </table>
    `;
}
document.getElementById('cmp-a').addEventListener('change', updateCmp);
document.getElementById('cmp-b').addEventListener('change', updateCmp);

document.getElementById('calc-body').innerHTML = opts;
document.getElementById('calc-body').value = 'mars';
function updateCalc() {
    const b = SPACE_OBJECTS.find(o => o.id === document.getElementById('calc-body').value);
    const m = parseFloat(document.getElementById('calc-mass').value) || 70;
    const weight = m * b.g;
    const G = 6.6743e-11;
    const v1 = Math.sqrt((G * b.massKg) / (b.rKm * 1000)) / 1000;
    document.getElementById('calc-output').innerHTML = `
        <div class="metric-box"><div class="metric-title">Вес тела (P)</div><div class="metric-value">${weight.toFixed(1)} Н</div></div>
        <div class="metric-box"><div class="metric-title">Ощущается как</div><div class="metric-value">${(weight / 9.81).toFixed(1)} кг</div></div>
        <div class="metric-box"><div class="metric-title">1-я косм. скорость</div><div class="metric-value">${v1.toFixed(2)} км/с</div></div>
    `;
}
document.getElementById('calc-body').addEventListener('change', updateCalc);
document.getElementById('calc-mass').addEventListener('input', updateCalc);

showInspector(selected);
renderAtlas('all');
updateCmp();
updateCalc();
drawSpace();
