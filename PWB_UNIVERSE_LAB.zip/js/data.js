
const UNIVERSE_OBJECTS = [
    // Планеты + Плутон + Спутники
    {
        id: 'mercury', name: 'Меркурий', category: 'planets', type: 'Планета земной группы',
        color: '#a8a29e', radiusKm: 2439.7, massKg: 3.301e23, massEarth: 0.055,
        gravity: 3.7, tempC: '167 °C (от -180 до +430)', dayHours: 1407.6, yearDays: 88,
        moons: 0, distanceAU: 0.39, orbitSpeed: 4.15, visualRadius: 6,
        atmosphere: 'Следы (O₂, Na, H₂, He)',
        description: 'Самая близкая к Солнцу и наименьшая планета Солнечной системы. Имеет крупное железное ядро.'
    },
    {
        id: 'venus', name: 'Венера', category: 'planets', type: 'Планета земной группы',
        color: '#fde047', radiusKm: 6051.8, massKg: 4.867e24, massEarth: 0.815,
        gravity: 8.87, tempC: '464 °C', dayHours: -5832.5, yearDays: 224.7,
        moons: 0, distanceAU: 0.72, orbitSpeed: 1.62, visualRadius: 9,
        atmosphere: '96.5% CO₂, 3.5% N₂ (92 атм)',
        description: 'Самая горячая планета Солнечной системы из-за мощного парникового эффекта. Вращается в обратную сторону.'
    },
    {
        id: 'earth', name: 'Земля', category: 'planets', type: 'Планета земной группы',
        color: '#38bdf8', radiusKm: 6371, massKg: 5.972e24, massEarth: 1.0,
        gravity: 9.81, tempC: '15 °C', dayHours: 23.93, yearDays: 365.25,
        moons: 1, distanceAU: 1.0, orbitSpeed: 1.0, visualRadius: 10,
        atmosphere: '78% N₂, 21% O₂, 1% Ar (1 атм)',
        description: 'Единственное известное астрономическое тело, населённое живыми организмами. Имеет жидкую гидросферу.'
    },
    {
        id: 'moon', name: 'Луна (спутник Земли)', category: 'planets', type: 'Естественный спутник',
        color: '#cbd5e1', radiusKm: 1737.4, massKg: 7.342e22, massEarth: 0.0123,
        gravity: 1.62, tempC: '-20 °C (от -173 до +127)', dayHours: 655.7, yearDays: 27.3,
        moons: 0, distanceAU: 1.0, orbitSpeed: 1.0, visualRadius: 4,
        atmosphere: 'Практически отсутствует (вакуум)',
        description: 'Единственный естественный спутник Земли. Вызывает приливы и стабилизирует наклон земной оси.'
    },
    {
        id: 'mars', name: 'Марс', category: 'planets', type: 'Планета земной группы',
        color: '#f97316', radiusKm: 3389.5, massKg: 6.417e23, massEarth: 0.107,
        gravity: 3.72, tempC: '-65 °C', dayHours: 24.62, yearDays: 687,
        moons: 2, distanceAU: 1.52, orbitSpeed: 0.53, visualRadius: 7.5,
        atmosphere: '95% CO₂, 2.6% N₂, 1.9% Ar (0.006 атм)',
        description: 'Красная планета с крупнейшим вулканом Солнечной системы (Олимп) и двумя спутниками — Фобосом и Деймосом.'
    },
    {
        id: 'jupiter', name: 'Юпитер', category: 'planets', type: 'Газовый гигант',
        color: '#fb923c', radiusKm: 69911, massKg: 1.898e27, massEarth: 317.8,
        gravity: 24.79, tempC: '-110 °C', dayHours: 9.93, yearDays: 4333,
        moons: 95, distanceAU: 5.2, orbitSpeed: 0.084, visualRadius: 20,
        atmosphere: '90% H₂, 10% He',
        description: 'Крупнейшая планета Солнечной системы. Известна Большим Красным Пятном и четырьмя галилеевыми спутниками.'
    },
    {
        id: 'saturn', name: 'Сатурн', category: 'planets', type: 'Газовый гигант',
        color: '#fde68a', radiusKm: 58232, massKg: 5.683e26, massEarth: 95.2,
        gravity: 10.44, tempC: '-140 °C', dayHours: 10.7, yearDays: 10759,
        moons: 146, distanceAU: 9.58, orbitSpeed: 0.034, visualRadius: 17, hasRings: true,
        atmosphere: '96% H₂, 3% He',
        description: 'Обладает самой развитой системой колец из льда и пыли. Средняя плотность Сатурна меньше плотности воды.'
    },
    {
        id: 'uranus', name: 'Уран', category: 'planets', type: 'Ледяной гигант',
        color: '#67e8f9', radiusKm: 25362, massKg: 8.681e25, massEarth: 14.5,
        gravity: 8.69, tempC: '-195 °C', dayHours: -17.24, yearDays: 30687,
        moons: 28, distanceAU: 19.2, orbitSpeed: 0.012, visualRadius: 13,
        atmosphere: '83% H₂, 15% He, 2.3% CH₄',
        description: 'Вращается «лёжа на боку» — наклон оси составляет 97.8°. Метан придаёт атмосфере голубой оттенок.'
    },
    {
        id: 'neptune', name: 'Нептун', category: 'planets', type: 'Ледяной гигант',
        color: '#3b82f6', radiusKm: 24622, massKg: 1.024e26, massEarth: 17.1,
        gravity: 11.15, tempC: '-200 °C', dayHours: 16.11, yearDays: 60190,
        moons: 16, distanceAU: 30.05, orbitSpeed: 0.006, visualRadius: 12.5,
        atmosphere: '80% H₂, 19% He, 1.5% CH₄',
        description: 'Самая дальняя планета Солнечной системы с самыми быстрыми ветрами (до 2100 км/ч).'
    },
    {
        id: 'pluto', name: 'Плутон', category: 'planets', type: 'Карликовая планета',
        color: '#d6d3d1', radiusKm: 1188.3, massKg: 1.303e22, massEarth: 0.0022,
        gravity: 0.62, tempC: '-229 °C', dayHours: -153.3, yearDays: 90560,
        moons: 5, distanceAU: 39.48, orbitSpeed: 0.004, visualRadius: 4.5,
        atmosphere: 'Разрежённая (N₂, CH₄, CO)',
        description: 'Крупнейшая карликовая планета пояса Койпера. Имеет ледяное плато Спутник в форме сердца.'
    },

    // Звёзды
    {
        id: 'sun', name: 'Солнце', category: 'stars', type: 'Жёлтый карлик (G2V)',
        color: '#fbbf24', radiusKm: 696340, massKg: 1.989e30, massEarth: 332946,
        gravity: 274.0, tempC: '5 500 °C (ядро 15 млн °C)', dayHours: 609.12, yearDays: 0,
        moons: 0, distanceAU: 0, orbitSpeed: 0, visualRadius: 28,
        atmosphere: '73% H, 25% He (фотосфера, хромосфера, корона)',
        description: 'Центральная звезда Солнечной системы, содержащая 99.86% всей её массы. Источник энергии — термоядерный синтез.'
    },
    {
        id: 'sirius', name: 'Сириус A', category: 'stars', type: 'Звезда главной последовательности (A1V)',
        color: '#e0f2fe', radiusKm: 1190000, massKg: 4.018e30, massEarth: 672000,
        gravity: 190.0, tempC: '9 667 °C', dayHours: 132, yearDays: 0,
        moons: 0, distanceAU: 544000, orbitSpeed: 0, visualRadius: 22,
        atmosphere: 'Водородно-гелиевая плазма',
        description: 'Самая яркая звезда ночного неба Земли (8.6 световых лет). В 25 раз светимее Солнца.'
    },
    {
        id: 'vega', name: 'Вега', category: 'stars', type: 'Белая звезда (A0V)',
        color: '#bae6fd', radiusKm: 1643000, massKg: 4.246e30, massEarth: 710000,
        gravity: 105.0, tempC: '9 327 °C', dayHours: 12.5, yearDays: 0,
        moons: 0, distanceAU: 1580000, orbitSpeed: 0, visualRadius: 23,
        atmosphere: 'Водородно-гелиевая плазма',
        description: 'Эталон нулевой звёздной величины. Быстро вращается вокруг своей оси, из-за чего сплюснута у полюсов.'
    },
    {
        id: 'betelgeuse', name: 'Бетельгейзе', category: 'stars', type: 'Красный сверхгигант (M1-2)',
        color: '#ef4444', radiusKm: 617000000, massKg: 2.188e31, massEarth: 3660000,
        gravity: 0.003, tempC: '3 227 °C', dayHours: 72000, yearDays: 0,
        moons: 0, distanceAU: 40000000, orbitSpeed: 0, visualRadius: 34,
        atmosphere: 'Протяжённая конвективная оболочка',
        description: 'Один из крупнейших известных сверхгигантов. Если поместить её на место Солнца, она поглотит орбиту Марса.'
    },
    {
        id: 'rigel', name: 'Ригель', category: 'stars', type: 'Голубой сверхгигант (B8Ia)',
        color: '#60a5fa', radiusKm: 54890000, massKg: 4.177e31, massEarth: 6990000,
        gravity: 0.92, tempC: '11 827 °C', dayHours: 1400, yearDays: 0,
        moons: 0, distanceAU: 54500000, orbitSpeed: 0, visualRadius: 29,
        atmosphere: 'Ионизированный гелий и водород',
        description: 'Ярчайшая звезда в созвездии Ориона со светимостью около 120 000 солнечных.'
    },

    // Чёрные дыры
    {
        id: 'sgr_a', name: 'Стрелец A* (Sagittarius A*)', category: 'blackholes', type: 'Сверхмассивная чёрная дыра',
        color: '#f59e0b', radiusKm: 12700000, massKg: 8.54e36, massEarth: 1.43e12,
        gravity: 3.5e6, tempC: 'Аккреционный диск: > 10 млн °C', dayHours: 0.18, yearDays: 0,
        moons: 0, distanceAU: 1.68e9, orbitSpeed: 0, visualRadius: 25,
        atmosphere: 'Релятивистская плазма аккреционного диска',
        description: 'Сверхмассивная чёрная дыра в центре нашей галактики Млечный Путь массой 4.3 млн масс Солнца.'
    },
    {
        id: 'm87', name: 'M87* (Поэхи)', category: 'blackholes', type: 'Сверхмассивная чёрная дыра',
        color: '#ea580c', radiusKm: 1.92e10, massKg: 1.29e40, massEarth: 2.16e15,
        gravity: 2300, tempC: 'Джеты: > 1 млрд °C', dayHours: 48, yearDays: 0,
        moons: 0, distanceAU: 3.4e12, orbitSpeed: 0, visualRadius: 32,
        atmosphere: 'Магнитоактивный аккреционный поток и джет',
        description: 'Первая в истории чёрная дыра, чью тень удалось сфотографировать телескопу Event Horizon Telescope (масса 6.5 млрд солнц).'
    },
    {
        id: 'cygnus_x1', name: 'Cygnus X-1 (Лебедь X-1)', category: 'blackholes', type: 'Чёрная дыра звёздной массы',
        color: '#a855f7', radiusKm: 62.6, massKg: 4.21e31, massEarth: 7050000,
        gravity: 7.1e11, tempC: 'Рентгеновский диск: ~2 млн °C', dayHours: 0.001, yearDays: 5.6,
        moons: 0, distanceAU: 3.8e8, orbitSpeed: 0, visualRadius: 15,
        atmosphere: 'Перетекание газа со звезды-компаньона HDE 226868',
        description: 'Один из первых и наиболее изученных кандидатов в чёрные дыры в двойной рентгеновской системе (масса 21.2 солнц).'
    },

    // Галактики и туманности
    {
        id: 'milky_way', name: 'Млечный Путь', category: 'galaxies', type: 'Спиральная галактика с перемычкой',
        color: '#c084fc', radiusKm: 5.0e17, massKg: 2.3e42, massEarth: 3.8e17,
        gravity: 1e-10, tempC: 'Межзвёздная среда: от -260 до +10⁶ °C', dayHours: 0, yearDays: 8.4e10,
        moons: 0, distanceAU: 0, orbitSpeed: 0, visualRadius: 30,
        atmosphere: 'Межзвёздный газ (H I, H II) и космическая пыль',
        description: 'Наша родная галактика диаметром около 105 700 световых лет, содержащая от 100 до 400 миллиардов звёзд.'
    },
    {
        id: 'andromeda', name: 'Галактика Андромеды (M31)', category: 'galaxies', type: 'Спиральная галактика',
        color: '#818cf8', radiusKm: 1.04e18, massKg: 3.0e42, massEarth: 5.0e17,
        gravity: 1e-10, tempC: 'Межзвёздная среда: ~ -250 °C', dayHours: 0, yearDays: 0,
        moons: 0, distanceAU: 1.6e11, orbitSpeed: 0, visualRadius: 33,
        atmosphere: 'Около 1 триллиона звёзд и газопылевые рукава',
        description: 'Ближайшая к Млечному Пути крупная галактика (2.5 млн световых лет). Движется навстречу нашей галактике.'
    },
    {
        id: 'orion_nebula', name: 'Туманность Ориона (M42)', category: 'galaxies', type: 'Диффузная эмиссионная туманность',
        color: '#f472b6', radiusKm: 1.13e14, massKg: 3.97e33, massEarth: 6.6e8,
        gravity: 1e-12, tempC: 'Ионизированный газ: ~9 700 °C', dayHours: 0, yearDays: 0,
        moons: 0, distanceAU: 8.5e7, orbitSpeed: 0, visualRadius: 24,
        atmosphere: 'Ионизированный водород, гелий, кислород',
        description: 'Ближайшая к Земле область активного звездообразования («звёздные ясли»), видимая невооружённым глазом.'
    },

    // Космические тела
    {
        id: 'halley', name: 'Комета Галлея (1P/Halley)', category: 'bodies', type: 'Короткопериодическая комета',
        color: '#2dd4bf', radiusKm: 5.5, massKg: 2.2e14, massEarth: 3.7e-11,
        gravity: 0.0005, tempC: 'От -200 до +100 °C в перигелии', dayHours: 52.8, yearDays: 27510,
        moons: 0, distanceAU: 17.8, orbitSpeed: 0.013, visualRadius: 5,
        atmosphere: 'Временная кома из водяного пара, CO и пыли',
        description: 'Самая известная комета, возвращающаяся к Солнцу каждые 75–76 лет. Имеет вытянутую ретроградную орбиту.'
    },
    {
        id: 'ceres', name: 'Церера (1 Ceres)', category: 'bodies', type: 'Астероид / Карликовая планета',
        color: '#9ca3af', radiusKm: 469.7, massKg: 9.38e20, massEarth: 0.00016,
        gravity: 0.28, tempC: '-105 °C', dayHours: 9.07, yearDays: 1682,
        moons: 0, distanceAU: 2.77, orbitSpeed: 0.217, visualRadius: 5,
        atmosphere: 'Крайне разрежённый водяной пар',
        description: 'Крупнейший объект главного пояса астероидов между Марсом и Юпитером (около трети массы всего пояса).'
    },
    {
        id: 'crab_pulsar', name: 'Пульсар в Крабовидной туманности', category: 'bodies', type: 'Нейтронная звезда (пульсар)',
        color: '#38bdf8', radiusKm: 10.0, massKg: 2.78e30, massEarth: 465000,
        gravity: 1.85e12, tempC: 'Поверхность: ~1.6 млн °C', dayHours: 0.000009, yearDays: 0,
        moons: 0, distanceAU: 4.1e8, orbitSpeed: 0, visualRadius: 8,
        atmosphere: 'Сверхплотная кора из ядер железа и магнитосфера',
        description: 'Остаток сверхновой 1054 года. Совершает 30 оборотов в секунду; чайная ложка его вещества весит миллиарды тонн.'
    },
    {
        id: 'sn1987a', name: 'Сверхновая SN 1987A', category: 'bodies', type: 'Остаток сверхновой II типа',
        color: '#fb7185', radiusKm: 1.5e13, massKg: 3.5e31, massEarth: 5.8e6,
        gravity: 1e-9, tempC: 'Ударная волна: > 10 млн °C', dayHours: 0, yearDays: 0,
        moons: 0, distanceAU: 1.06e10, orbitSpeed: 0, visualRadius: 20,
        atmosphere: 'Расширяющаяся оболочка тяжёлых элементов',
        description: 'Вспышка сверхновой в Большом Магеллановом Облаке. Позволила впервые зарегистрировать нейтрино от коллапса ядра.'
    }
];
