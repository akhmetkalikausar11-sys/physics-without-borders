
// Навигация
document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.dataset.target).classList.add('active');
        if (btn.dataset.target === 'lab-section') {
            drawPhysicsChart();
        }
    });
});

// ================= 1. ИНТЕРАКТИВНАЯ 3D-МОДЕЛЬ КОСМОСА =================
const canvas = document.getElementById('space-canvas');
const ctx = canvas.getContext('2d');

let width, height;
let rotX = 0.45;
let rotY = 0.0;
let zoom = 1.0;
let timeScale = 1.0;
let simTime = 0;
let isDragging = false;
let lastMouseX = 0, lastMouseY = 0;
let activeScene = 'solar'; // solar | showcase
let selectedObj = UNIVERSE_OBJECTS.find(o => o.id === 'earth');
let renderedNodes = [];

// Звёздный фон
const bgStars = Array.from({ length: 320 }, () => ({
    x: (Math.random() - 0.5) * 2000,
    y: (Math.random() - 0.5) * 2000,
    z: (Math.random() - 0.5) * 2000,
    size: Math.random() * 1.8 + 0.4,
    alpha: Math.random() * 0.7 + 0.3
}));

function resizeCanvas() {
    const container = document.getElementById('viewport-section');
    width = canvas.width = container.clientWidth;
    height = canvas.height = container.clientHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// Управление мышью и тачем
canvas.addEventListener('mousedown', e => {
    isDragging = true;
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
});

window.addEventListener('mouseup', e => {
    if (isDragging && Math.hypot(e.clientX - lastMouseX, e.clientY - lastMouseY) < 5) {
        handleCanvasClick(e.clientX, e.clientY);
    }
    isDragging = false;
});

window.addEventListener('mousemove', e => {
    if (!isDragging) return;
    const dx = e.clientX - lastMouseX;
    const dy = e.clientY - lastMouseY;
    rotY += dx * 0.006;
    rotX = Math.max(-1.4, Math.min(1.4, rotX + dy * 0.006));
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
});

canvas.addEventListener('wheel', e => {
    e.preventDefault();
    const factor = e.deltaY > 0 ? 0.9 : 1.1;
    zoom = Math.max(0.25, Math.min(4.5, zoom * factor));
    document.getElementById('zoom-slider').value = zoom;
    document.getElementById('zoom-val').textContent = zoom.toFixed(2) + 'x';
}, { passive: false });

// Тач-управление для телефонов
let initialPinchDist = null;
canvas.addEventListener('touchstart', e => {
    if (e.touches.length === 1) {
        isDragging = true;
        lastMouseX = e.touches[0].clientX;
        lastMouseY = e.touches[0].clientY;
    } else if (e.touches.length === 2) {
        initialPinchDist = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
        );
    }
});

canvas.addEventListener('touchmove', e => {
    e.preventDefault();
    if (e.touches.length === 1 && isDragging) {
        const dx = e.touches[0].clientX - lastMouseX;
        const dy = e.touches[0].clientY - lastMouseY;
        rotY += dx * 0.007;
        rotX = Math.max(-1.4, Math.min(1.4, rotX + dy * 0.007));
        lastMouseX = e.touches[0].clientX;
        lastMouseY = e.touches[0].clientY;
    } else if (e.touches.length === 2 && initialPinchDist) {
        const dist = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
        );
        zoom = Math.max(0.25, Math.min(4.5, zoom * (dist / initialPinchDist)));
        initialPinchDist = dist;
        document.getElementById('zoom-slider').value = zoom;
        document.getElementById('zoom-val').textContent = zoom.toFixed(2) + 'x';
    }
}, { passive: false });

canvas.addEventListener('touchend', e => {
    if (isDragging && e.changedTouches.length === 1) {
        handleCanvasClick(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
    }
    isDragging = false;
    initialPinchDist = null;
});

function handleCanvasClick(clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    const mx = clientX - rect.left;
    const my = clientY - rect.top;
    for (let i = renderedNodes.length - 1; i >= 0; i--) {
        const node = renderedNodes[i];
        if (Math.hypot(mx - node.screenX, my - node.screenY) <= Math.max(14, node.screenR + 4)) {
            selectObject(node.obj);
            break;
        }
    }
}

function project3D(x, y, z) {
    // Поворот вокруг Y
    const cosY = Math.cos(rotY), sinY = Math.sin(rotY);
    const x1 = x * cosY - z * sinY;
    const z1 = z * cosY + x * sinY;

    // Поворот вокруг X
    const cosX = Math.cos(rotX), sinX = Math.sin(rotX);
    const y2 = y * cosX - z1 * sinX;
    const z2 = z1 * cosX + y * sinX;

    const fov = 750;
    const scale = (fov / (fov + z2 + 400)) * zoom;
    return {
        x: width / 2 + x1 * scale,
        y: height / 2 + y2 * scale,
        scale: scale,
        z: z2
    };
}

function selectObject(obj) {
    selectedObj = obj;
    const inspector = document.getElementById('object-inspector');
    inspector.innerHTML = `
        <div class="hud-title">
            <span>${obj.name}</span>
            <span class="card-badge" style="margin:0">${obj.type}</span>
        </div>
        <p style="font-size:0.85rem; color:var(--text-muted); margin-bottom:10px;">${obj.description}</p>
        <div class="stat-grid">
            <div class="stat-card"><div class="stat-label">Радиус</div><div class="stat-val">${obj.radiusKm.toLocaleString('ru-RU')} км</div></div>
            <div class="stat-card"><div class="stat-label">Масса</div><div class="stat-val">${obj.massKg.toExponential(2)} кг</div></div>
            <div class="stat-card"><div class="stat-label">Гравитация (g)</div><div class="stat-val">${obj.gravity} м/с²</div></div>
            <div class="stat-card"><div class="stat-label">Температура</div><div class="stat-val">${obj.tempC}</div></div>
            <div class="stat-card"><div class="stat-label">Сутки</div><div class="stat-val">${obj.dayHours ? obj.dayHours + ' ч' : '—'}</div></div>
            <div class="stat-card"><div class="stat-label">Спутники</div><div class="stat-val">${obj.moons}</div></div>
        </div>
        <div class="stat-card" style="margin-top:8px;">
            <div class="stat-label">Атмосфера / Среда</div>
            <div class="stat-val" style="font-size:0.82rem;">${obj.atmosphere}</div>
        </div>
    `;
}

function drawScene() {
    ctx.fillStyle = '#060812';
    ctx.fillRect(0, 0, width, height);

    // Звёздный фон
    bgStars.forEach(s => {
        const p = project3D(s.x, s.y, s.z);
        if (p.scale > 0) {
            ctx.fillStyle = `rgba(255, 255, 255, ${s.alpha})`;
            ctx.beginPath();
            ctx.arc(p.x, p.y, s.size * Math.min(1.5, p.scale), 0, Math.PI * 2);
            ctx.fill();
        }
    });

    renderedNodes = [];
    const showOrbits = document.getElementById('toggle-orbits').checked;
    const showLabels = document.getElementById('toggle-labels').checked;

    if (activeScene === 'solar') {
        const solarOrder = ['sun', 'mercury', 'venus', 'earth', 'mars', 'ceres', 'jupiter', 'saturn', 'uranus', 'neptune', 'pluto', 'halley'];
        const orbitRadii = [0, 52, 78, 108, 140, 168, 215, 270, 325, 375, 420, 290];

        solarOrder.forEach((id, idx) => {
            const obj = UNIVERSE_OBJECTS.find(o => o.id === id);
            const rOrbit = orbitRadii[idx];

            // Рисуем орбиту
            if (showOrbits && rOrbit > 0) {
                ctx.strokeStyle = id === 'halley' ? 'rgba(45, 212, 191, 0.25)' : 'rgba(148, 163, 184, 0.2)';
                ctx.lineWidth = 1;
                ctx.beginPath();
                for (let a = 0; a <= Math.PI * 2 + 0.1; a += 0.1) {
                    const ox = id === 'halley' ? Math.cos(a) * rOrbit * 1.3 - 80 : Math.cos(a) * rOrbit;
                    const oz = id === 'halley' ? Math.sin(a) * rOrbit * 0.55 : Math.sin(a) * rOrbit;
                    const op = project3D(ox, 0, oz);
                    if (a === 0) ctx.moveTo(op.x, op.y);
                    else ctx.lineTo(op.x, op.y);
                }
                ctx.stroke();
            }

            const angle = simTime * obj.orbitSpeed * 0.4 + idx * 1.1;
            const x = id === 'halley' ? Math.cos(angle) * rOrbit * 1.3 - 80 : Math.cos(angle) * rOrbit;
            const z = id === 'halley' ? Math.sin(angle) * rOrbit * 0.55 : Math.sin(angle) * rOrbit;
            const p = project3D(x, 0, z);

            if (p.scale > 0) {
                renderedNodes.push({ obj, screenX: p.x, screenY: p.y, screenR: obj.visualRadius * p.scale, z: p.z, x, z });
            }

            // Луна вокруг Земли
            if (id === 'earth') {
                const moonObj = UNIVERSE_OBJECTS.find(o => o.id === 'moon');
                const mAngle = simTime * 4.5;
                const mx = x + Math.cos(mAngle) * 18;
                const mz = z + Math.sin(mAngle) * 18;
                const mp = project3D(mx, 0, mz);
                if (mp.scale > 0) {
                    renderedNodes.push({ obj: moonObj, screenX: mp.x, screenY: mp.y, screenR: moonObj.visualRadius * mp.scale, z: mp.z });
                }
            }
        });
    } else {
        // Галактическая и экзотическая панорама (звёзды, чёрные дыры, туманности)
        const deepObjects = UNIVERSE_OBJECTS.filter(o => o.category !== 'planets' || o.id === 'earth');
        deepObjects.forEach((obj, idx) => {
            const ring = 90 + (idx % 4) * 85;
            const angle = (idx / deepObjects.length) * Math.PI * 2 + simTime * 0.08;
            const yOffset = ((idx % 3) - 1) * 45;
            const x = Math.cos(angle) * ring;
            const z = Math.sin(angle) * ring;
            const p = project3D(x, yOffset, z);
            if (p.scale > 0) {
                renderedNodes.push({ obj, screenX: p.x, screenY: p.y, screenR: obj.visualRadius * p.scale, z: p.z });
            }
        });
    }

    // Сортировка по глубине (алгоритм художника)
    renderedNodes.sort((a, b) => b.z - a.z);

    renderedNodes.forEach(node => {
        const { obj, screenX, screenY, screenR } = node;

        // Свечение для звёзд и чёрных дыр
        if (obj.category === 'stars' || obj.category === 'blackholes' || obj.id === 'sun') {
            const grad = ctx.createRadialGradient(screenX, screenY, screenR * 0.2, screenX, screenY, screenR * 2.5);
            grad.addColorStop(0, obj.color);
            grad.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(screenX, screenY, screenR * 2.5, 0, Math.PI * 2);
            ctx.fill();
        }

        // Кольца Сатурна
        if (obj.hasRings) {
            ctx.strokeStyle = 'rgba(253, 230, 138, 0.65)';
            ctx.lineWidth = Math.max(2, screenR * 0.35);
            ctx.beginPath();
            ctx.ellipse(screenX, screenY, screenR * 2.1, screenR * 0.65, 0.25, 0, Math.PI * 2);
            ctx.stroke();
        }

        // Тело объекта
        ctx.fillStyle = obj.category === 'blackholes' ? '#000000' : obj.color;
        ctx.beginPath();
        ctx.arc(screenX, screenY, Math.max(3, screenR), 0, Math.PI * 2);
        ctx.fill();

        if (obj.category === 'blackholes') {
            ctx.strokeStyle = obj.color;
            ctx.lineWidth = 2.5;
            ctx.stroke();
        }

        // Выделение активного объекта
        if (selectedObj && selectedObj.id === obj.id) {
            ctx.strokeStyle = '#38bdf8';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(screenX, screenY, Math.max(8, screenR + 6), 0, Math.PI * 2);
            ctx.stroke();
        }

        // Подпись
        if (showLabels) {
            ctx.fillStyle = '#e2e8f0';
            ctx.font = '12px sans-serif';
            ctx.fillText(obj.name, screenX + screenR + 6, screenY + 4);
        }
    });

    simTime += 0.016 * timeScale;
    requestAnimationFrame(drawScene);
}

// Контролы HUD
document.getElementById('speed-slider').addEventListener('input', e => {
    timeScale = parseFloat(e.target.value);
    document.getElementById('speed-val').textContent = timeScale.toFixed(1) + 'x';
});

document.getElementById('zoom-slider').addEventListener('input', e => {
    zoom = parseFloat(e.target.value);
    document.getElementById('zoom-val').textContent = zoom.toFixed(2) + 'x';
});

document.querySelectorAll('[data-scene]').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('[data-scene]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeScene = btn.dataset.scene;
    });
});

// ================= 2. КАТАЛОГ ВСЕЛЕННОЙ =================
function renderCatalog(filter = 'all') {
    const grid = document.getElementById('catalog-grid');
    const filtered = filter === 'all' ? UNIVERSE_OBJECTS : UNIVERSE_OBJECTS.filter(o => o.category === filter);
    grid.innerHTML = filtered.map(obj => `
        <div class="object-card" onclick="openIn3D('${obj.id}')">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <span class="card-badge">${obj.type}</span>
                <span style="width:14px; height:14px; border-radius:50%; background:${obj.color}; display:inline-block;"></span>
            </div>
            <h3 style="margin-bottom:6px;">${obj.name}</h3>
            <p style="font-size:0.85rem; color:var(--text-muted); margin-bottom:12px;">${obj.description}</p>
            <div style="font-size:0.82rem; color:#cbd5e1;">
                <div><strong>Масса:</strong> ${obj.massKg.toExponential(2)} кг</div>
                <div><strong>Радиус:</strong> ${obj.radiusKm.toLocaleString('ru-RU')} км</div>
                <div><strong>Гравитация:</strong> ${obj.gravity} м/с²</div>
            </div>
        </div>
    `).join('');
}

function openIn3D(id) {
    const obj = UNIVERSE_OBJECTS.find(o => o.id === id);
    if (!obj) return;
    selectObject(obj);
    activeScene = (obj.category === 'planets' || obj.id === 'sun' || obj.id === 'halley' || obj.id === 'ceres') ? 'solar' : 'showcase';
    document.querySelectorAll('[data-scene]').forEach(b => b.classList.toggle('active', b.dataset.scene === activeScene));
    document.querySelector('[data-target="viewport-section"]').click();
}

document.querySelectorAll('[data-filter]').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderCatalog(btn.dataset.filter);
    });
});

// ================= 3. СРАВНЕНИЕ КОСМИЧЕСКИХ ТЕЛ =================
function initComparison() {
    const selA = document.getElementById('comp-a');
    const selB = document.getElementById('comp-b');
    const options = UNIVERSE_OBJECTS.map(o => `<option value="${o.id}">${o.name} (${o.type})</option>`).join('');
    selA.innerHTML = options;
    selB.innerHTML = options;
    selA.value = 'earth';
    selB.value = 'jupiter';

    const updateComp = () => {
        const a = UNIVERSE_OBJECTS.find(o => o.id === selA.value);
        const b = UNIVERSE_OBJECTS.find(o => o.id === selB.value);
        const massRatio = (b.massKg / a.massKg).toExponential(2);
        const radiusRatio = (b.radiusKm / a.radiusKm).toFixed(2);
        document.getElementById('comp-result').innerHTML = `
            <table class="comp-table">
                <thead>
                    <tr><th>Параметр</th><th>${a.name}</th><th>${b.name}</th></tr>
                </thead>
                <tbody>
                    <tr><td>Категория</td><td>${a.type}</td><td>${b.type}</td></tr>
                    <tr><td>Масса (кг)</td><td>${a.massKg.toExponential(2)}</td><td>${b.massKg.toExponential(2)}</td></tr>
                    <tr><td>Масса (в массах Земли)</td><td>${a.massEarth}</td><td>${b.massEarth}</td></tr>
                    <tr><td>Радиус (км)</td><td>${a.radiusKm.toLocaleString('ru-RU')}</td><td>${b.radiusKm.toLocaleString('ru-RU')}</td></tr>
                    <tr><td>Гравитация (м/с²)</td><td>${a.gravity}</td><td>${b.gravity}</td></tr>
                    <tr><td>Температура</td><td>${a.tempC}</td><td>${b.tempC}</td></tr>
                    <tr><td>Продолжительность суток</td><td>${a.dayHours} ч</td><td>${b.dayHours} ч</td></tr>
                </tbody>
            </table>
            <div class="formula-box" style="margin-top:16px;">
                Отношение масс (${b.name} / ${a.name}): <strong>${massRatio}</strong> | 
                Отношение радиусов: <strong>${radiusRatio}x</strong>
            </div>
        `;
    };
    selA.addEventListener('change', updateComp);
    selB.addEventListener('change', updateComp);
    updateComp();
}

// ================= 4. ФИЗИЧЕСКАЯ ЛАБОРАТОРИЯ =================
function initPhysicsLab() {
    const bodySel = document.getElementById('lab-body');
    bodySel.innerHTML = UNIVERSE_OBJECTS.map(o => `<option value="${o.id}">${o.name} (g = ${o.gravity} м/с²)</option>`).join('');
    bodySel.value = 'mars';

    const massInput = document.getElementById('lab-mass');
    const starMassInput = document.getElementById('lab-star-mass');
    const orbitDistInput = document.getElementById('lab-orbit-dist');

    function calculateLab() {
        const body = UNIVERSE_OBJECTS.find(o => o.id === bodySel.value);
        const m = parseFloat(massInput.value) || 70;
        const weightN = m * body.gravity;
        const weightEarthEq = weightN / 9.81;

        // Первая космическая скорость v1 = sqrt(G * M / R)
        const G = 6.6743e-11;
        const v1 = Math.sqrt((G * body.massKg) / (body.radiusKm * 1000)) / 1000;

        document.getElementById('lab-weight-out').innerHTML = `
            <div>Вес тела на <strong>${body.name}</strong>: <span style="color:var(--accent); font-weight:700;">${weightN.toFixed(2)} Н</span> (ощущается как <strong>${weightEarthEq.toFixed(2)} кг</strong> на Земле)</div>
            <div style="margin-top:6px;">Первая космическая скорость (v₁): <span style="color:var(--gold); font-weight:700;">${v1.toFixed(2)} км/с</span></div>
        `;

        // Орбитальная скорость и светимость
        const M_sun = parseFloat(starMassInput.value) || 1.0;
        const r_au = parseFloat(orbitDistInput.value) || 1.0;
        const v_orb = 29.78 * Math.sqrt(M_sun / r_au); // км/с
        const period_yr = Math.sqrt(Math.pow(r_au, 3) / M_sun);
        const luminosity = Math.pow(M_sun, 3.5); // L ~ M^3.5 для главной последовательности

        document.getElementById('lab-orbit-out').innerHTML = `
            <div>Орбитальная скорость: <span style="color:var(--accent); font-weight:700;">${v_orb.toFixed(2)} км/с</span></div>
            <div>Орбитальный период (год): <span style="color:var(--gold); font-weight:700;">${period_yr.toFixed(2)} земных лет</span></div>
            <div>Светимость звезды (L ≈ M³·⁵): <span style="color:#f472b6; font-weight:700;">${luminosity.toFixed(2)} L☉</span></div>
        `;

        drawPhysicsChart();
    }

    [bodySel, massInput, starMassInput, orbitDistInput].forEach(el => el.addEventListener('input', calculateLab));
    calculateLab();
}

function drawPhysicsChart() {
    const c = document.getElementById('physics-chart');
    if (!c) return;
    const cx = c.getContext('2d');
    const w = c.width = c.clientWidth || 500;
    const h = c.height = 220;

    cx.clearRect(0, 0, w, h);
    cx.strokeStyle = 'rgba(255,255,255,0.15)';
    cx.beginPath();
    cx.moveTo(40, 20);
    cx.lineTo(40, h - 30);
    cx.lineTo(w - 20, h - 30);
    cx.stroke();

    // График зависимости орбитальной скорости от расстояния (1 / sqrt(r))
    const M_sun = parseFloat(document.getElementById('lab-star-mass').value) || 1.0;
    cx.strokeStyle = '#38bdf8';
    cx.lineWidth = 2.5;
    cx.beginPath();
    for (let px = 40; px < w - 25; px++) {
        const r = 0.3 + ((px - 40) / (w - 65)) * 10; // от 0.3 до 10.3 а.е.
        const v = 29.78 * Math.sqrt(M_sun / r);
        const py = (h - 30) - Math.min(h - 45, (v / 65) * (h - 45));
        if (px === 40) cx.moveTo(px, py);
        else cx.lineTo(px, py);
    }
    cx.stroke();

    cx.fillStyle = '#94a3b8';
    cx.font = '12px sans-serif';
    cx.fillText('Орбитальная скорость v(r) от расстояния (0.3 – 10 а.е.)', 50, 24);
    cx.fillText('Расстояние r (а.е.) →', w - 130, h - 10);
}

// Инициализация
selectObject(selectedObj);
renderCatalog('all');
initComparison();
initPhysicsLab();
drawScene();
